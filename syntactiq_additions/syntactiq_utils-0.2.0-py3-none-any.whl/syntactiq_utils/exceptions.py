"""Custom exceptions for the Syntactiq Utils package."""


class SyntactiqException(Exception):
    """Base exception class for all custom exceptions in this package."""

    pass


class ConnectionError(SyntactiqException):
    """Raised when there is an issue connecting to a database."""

    pass


class QueryError(SyntactiqException):
    """Raised when a database query fails."""

    pass


class TableNotFound(SyntactiqException):
    """Raised when a table is not found in the database."""

    pass


class FileNotFoundError(SyntactiqException):
    """Raised when a file, such as an image for a report, is not found."""

    pass


class InvalidInputError(SyntactiqException):
    """Raised when a function receives an invalid input, like an empty DataFrame."""

    pass 