"""Syntactiq-Utils Data Subpackage."""

from .core import (
    SyntactiqDB,
    connect,
    close,
    create_table_from_query,
    explore_tables,
    get_table_schema,
    health_check,
    preview_data,
    query,
    show_table,
    table_to_df,
) 