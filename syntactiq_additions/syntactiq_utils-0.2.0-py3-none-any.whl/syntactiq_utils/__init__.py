"""Syntactiq Utils: A Python package for efficient database access and analysis."""

from .data import (
    connect,
    explore_tables,
    get_table_schema,
    create_table_from_query,
    query,
    preview_data,
    show_table,
    table_to_df,
    health_check,
    close,
)
from .exceptions import SyntactiqException
from .llm_docs import LLM_INSTRUCTIONS
from .reporting import Report

__all__ = [
    "connect",
    "explore_tables",
    "get_table_schema",
    "create_table_from_query",
    "query",
    "preview_data",
    "show_table",
    "table_to_df",
    "health_check",
    "close",
    "SyntactiqException",
    "LLM_INSTRUCTIONS",
    "Report",
] 