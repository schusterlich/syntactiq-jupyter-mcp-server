"""
This module provides the Report class for creating standardized PDF reports.
"""

import os
from typing import List, Any, Dict, Optional, Union
import pandas as pd
from borb.pdf import Document, Page, SingleColumnLayout, PDF, Paragraph, FlexibleColumnWidthTable, TableCell, Image
from borb.pdf.canvas.layout.layout_element import LayoutElement, Alignment
from borb.pdf.page.page_size import PageSize
from borb.pdf.canvas.color.color import HexColor, X11Color
from borb.pdf.canvas.line_art.line_art_factory import LineArtFactory
from borb.pdf.canvas.font.simple_font.true_type_font import TrueTypeFont
from decimal import Decimal

from ..config import get_report_config
from ..exceptions import FileNotFoundError, InvalidInputError
from ..fonts import get_font_path, get_default_font_path, load_fonts


class ElementReference:
    """
    A reference to a layout element that can be used for grouping.
    """
    def __init__(self, element: LayoutElement, element_type: str, content: str = ""):
        self.element = element
        self.element_type = element_type
        self.content = content
        self.id = id(element)  # Unique identifier
    
    def __repr__(self):
        return f"ElementReference({self.element_type}: {self.content[:50]}...)"


class ElementGroup:
    """
    A group of elements that should be kept together on the same page.
    """
    def __init__(self, name: str = ""):
        self.name = name
        self.elements: List[ElementReference] = []
        self.id = id(self)
    
    def add_element(self, element_ref: ElementReference):
        """Add an element reference to this group."""
        self.elements.append(element_ref)
    
    def get_borb_elements(self) -> List[LayoutElement]:
        """Get the actual borb elements for this group."""
        return [elem_ref.element for elem_ref in self.elements]
    
    def __repr__(self):
        return f"ElementGroup('{self.name}', {len(self.elements)} elements)"


class Report:
    """
    A class to generate professional, standardized PDF reports.
    """

    def __init__(self, author: str = "Syntactiq", title: str = "Report"):
        """
        Initializes the Report object, setting up the document structure.
        """
        self.config = get_report_config()
        self.doc: Document = Document()
        
        # Create page with proper academic margins (1 inch = 72 points)
        # A4 size: 595 x 842 points
        # With 72pt margins: content area = 451 x 698 points
        self.page: Page = Page()
        self.doc.add_page(self.page)
        self.layout = SingleColumnLayout(self.page)
        
        # Load custom fonts
        self.fonts = load_fonts()
        
        # Group management
        self.groups: Dict[str, ElementGroup] = {}
        self.pending_elements: List[Union[LayoutElement, ElementGroup]] = []
        
        # Track elements added to current page for space estimation
        self.current_page_elements = 0
        
        # Track page numbers
        self.current_page_number = 1
        self.pages_list = [self.page]  # Keep track of all pages
        
        # Add company logo to top right
        self._add_header_logo()

    def _add_element(self, element: LayoutElement, spacing: str = "normal"):
        """
        Adds a layout element to the PDF with appropriate spacing.
        
        Args:
            element: The layout element to add
            spacing: Type of spacing ('normal', 'section', 'title', 'none')
        """
        # Add debug border if enabled
        if self.config.get("debug_mode", False):
            # Apply debug styling using borb's native border properties
            if hasattr(element, 'border_color'):
                element.border_color = HexColor("#ff0000")
            if hasattr(element, 'border_width'):
                element.border_width = Decimal(2)
            if hasattr(element, 'border_top'):
                element.border_top = True
            if hasattr(element, 'border_bottom'):
                element.border_bottom = True
            if hasattr(element, 'border_left'):
                element.border_left = True
            if hasattr(element, 'border_right'):
                element.border_right = True
        
        self.layout.add(element)
        
        # Temporarily remove ALL spacers to see natural spacing
        # if spacing == "title":
        #     self.layout.add(self._create_spacer(self.config["title_spacing"]))
        # elif spacing == "section":
        #     self.layout.add(self._create_spacer(self.config["section_spacing"]))
        # Remove 'normal' spacing to eliminate gaps between headers and paragraphs

    def _create_spacer(self, height: int = None) -> LayoutElement:
        """
        Creates a vertical spacer.
        
        Args:
            height: Height of the spacer in points
        """
        if height is None:
            height = self.config["vertical_spacing"]
        
        # In debug mode, create a visible spacer
        if self.config.get("debug_mode", False):
            spacer = Paragraph(
                f"[SPACER {height}pt]",  # Visible text in debug mode
                font_size=Decimal(8),
                font_color=HexColor("#0000ff"),
                background_color=HexColor("#ffeeee"),
                border_color=HexColor("#0000ff"),
                border_width=Decimal(1),
                border_top=True,
                border_bottom=True,
                border_left=True,
                border_right=True,
                margin_bottom=Decimal(height),
            )
        else:
            # Use a minimal paragraph with proper margin instead of font_size for spacing
            spacer = Paragraph(
                "",  # Empty text
                font_size=Decimal(1),  # Minimal font size
                margin_bottom=Decimal(height),  # Use margin for spacing
            )
        
        return spacer

    def add_title(self, text: str, group: Optional[ElementGroup] = None) -> ElementReference:
        """
        Adds a title to the report.

        Args:
            text: The title text
            group: Optional group to add this element to

        Returns:
            ElementReference: Reference to the created title element
        """
        title = Paragraph(
            text,
            font=self.fonts['title'],
            font_size=Decimal(self.config['font_sizes']['title']),
            font_color=HexColor(self.config['colors']['text']),
            text_alignment=Alignment.LEFT,
            margin_top=Decimal(0),
            margin_bottom=Decimal(4)
        )
        
        return self._add_element_to_group(title, group, "title", text)

    def add_header(self, text: str, group: Optional[ElementGroup] = None) -> ElementReference:
        """
        Adds a header to the report.

        Args:
            text: The header text
            group: Optional group to add this element to

        Returns:
            ElementReference: Reference to the created header element
        """
        header = Paragraph(
            text,
            font=self.fonts['heading'],
            font_size=Decimal(self.config['font_sizes']['heading']),
            font_color=HexColor(self.config['colors']['text']),
            text_alignment=Alignment.LEFT,
            margin_top=Decimal(2),
            margin_bottom=Decimal(1)
        )
        
        return self._add_element_to_group(header, group, "header", text)

    def add_paragraph(self, text: str, group: Optional[ElementGroup] = None) -> ElementReference:
        """
        Adds a paragraph to the report.

        Args:
            text: The paragraph text
            group: Optional group to add this element to

        Returns:
            ElementReference: Reference to the created paragraph element
        """
        paragraph = Paragraph(
            text,
            font=self.fonts['body'],
            font_size=Decimal(self.config['font_sizes']['body']),
            font_color=HexColor(self.config['colors']['text']),
            text_alignment=Alignment.LEFT,
            margin_top=Decimal(1),
            margin_bottom=Decimal(1)
        )
        
        return self._add_element_to_group(paragraph, group, "paragraph", text[:50])

    def add_image(self, image_path: str, max_height: Optional[float] = None, 
                  group: Optional[ElementGroup] = None) -> ElementReference:
        """
        Adds an image to the report with proportional scaling.

        Args:
            image_path: Path to the image file
            max_height: Maximum height in points for the image (if None, uses default 200pt)
                       Width will be calculated proportionally to maintain aspect ratio
            group: Optional group to add this element to

        Returns:
            ElementReference: Reference to the created image element

        Raises:
            InvalidInputError: If the image file doesn't exist
        """
        if not os.path.exists(image_path):
            raise InvalidInputError(f"Image file not found at path: {image_path}. Please ensure the file exists and the path is correct.")

        try:
            # Load image using PIL first to get dimensions
            from PIL import Image as PILImage
            pil_image = PILImage.open(image_path)
            
            # Get original image dimensions
            original_width, original_height = pil_image.size
            aspect_ratio = original_width / original_height
            
            # Set default max height if not specified
            if max_height is None:
                max_height = 200  # Default 200pt height
            
            # Calculate proportional width based on max height
            calculated_height = Decimal(max_height)
            calculated_width = calculated_height * Decimal(aspect_ratio)
            
            # Get page content width (A4 width minus margins)
            page_width = Decimal(595)  # A4 width
            margin = Decimal(72)       # 1 inch margins
            max_content_width = page_width - (2 * margin)  # 451pt
            
            # If calculated width exceeds page content width, scale down
            if calculated_width > max_content_width:
                calculated_width = max_content_width
                calculated_height = calculated_width / Decimal(aspect_ratio)
            
            # Create the image with calculated dimensions
            image = Image(
                pil_image,
                width=calculated_width,
                height=calculated_height,
                horizontal_alignment=Alignment.CENTERED
            )

            return self._add_element_to_group(image, group, "image", os.path.basename(image_path))

        except Exception as e:
            raise InvalidInputError(f"Failed to load or process image from path: {image_path}. The file may be corrupted or in an unsupported format. Original error: {str(e)}")

    def add_highlight_box(self, type_text: str, content: str, group: Optional[ElementGroup] = None) -> ElementReference:
        """
        Adds a highlighted box with type and content.

        Args:
            type_text: The type/category text
            content: The main content text
            group: Optional group to add this element to

        Returns:
            ElementReference: Reference to the created highlight box element
        """
        # Combine type and content with a colon separator
        full_text = f"{type_text}: {content}"
        
        # Use a lighter version of the corporate color for better readability
        # This simulates 40% opacity by blending with white background
        light_highlight_color = HexColor("#FDF4D7")  # Light version of #F5AF00
        
        highlight_box = Paragraph(
            full_text,
            font="Helvetica-Oblique",  # Use italic font for highlight boxes
            font_size=Decimal(self.config['font_sizes']['body']),
            font_color=HexColor(self.config['colors']['text']),
            background_color=light_highlight_color,
            text_alignment=Alignment.LEFT,
            padding_top=Decimal(12),
            padding_bottom=Decimal(12),
            padding_left=Decimal(16),
            padding_right=Decimal(16),
            margin_top=Decimal(3),
            margin_bottom=Decimal(3)
        )
        
        return self._add_element_to_group(highlight_box, group, "highlight_box", full_text[:50])

    def add_data_table(self, data: pd.DataFrame, group: Optional[ElementGroup] = None) -> ElementReference:
        """
        Adds a data table to the report.

        Args:
            data: Pandas DataFrame to display as a table
            group: Optional group to add this element to

        Returns:
            ElementReference: Reference to the created table element

        Raises:
            InvalidInputError: If the DataFrame is empty or invalid
        """
        if not isinstance(data, pd.DataFrame) or data.empty:
            error_msg = "Cannot create a table from an empty or invalid DataFrame. Please provide a non-empty pandas.DataFrame."
            if not isinstance(data, pd.DataFrame):
                error_msg = f"Input data must be a pandas.DataFrame, but received type {type(data)}."
            raise InvalidInputError(error_msg)

        try:
            # Create table with headers
            num_cols = len(data.columns)
            num_rows = len(data) + 1  # +1 for header row

            # Create centered table with alternating row colors
            table = FlexibleColumnWidthTable(
                number_of_rows=num_rows, 
                number_of_columns=num_cols,
                horizontal_alignment=Alignment.CENTERED
            )

            # Add header row using TableCell with background color (simplified fonts)
            for col_idx, column_name in enumerate(data.columns):
                table.add(TableCell(
                    Paragraph(
                        str(column_name),
                        font="Helvetica-Bold",  # Use simple font name
                        font_size=Decimal(self.config['font_sizes']['body']),
                        font_color=X11Color("White"),
                        text_alignment=Alignment.LEFT
                    ),
                    background_color=X11Color("SlateGray")
                ))

            # Add data rows with alternating colors
            for row_idx, (_, row) in enumerate(data.iterrows()):
                # Determine row color (alternating between white and light gray)
                row_color = X11Color("WhiteSmoke") if row_idx % 2 == 0 else X11Color("White")
                
                for value in row:
                    table.add(TableCell(
                        Paragraph(
                            str(value),
                            font="Helvetica",  # Use simple font name
                            font_size=Decimal(self.config['font_sizes']['body']),
                            text_alignment=Alignment.LEFT
                        ),
                        background_color=row_color
                    ))

            # Set table styling for better appearance
            table.set_padding_on_all_cells(Decimal(8), Decimal(8), Decimal(8), Decimal(8))
            
            # Add borders for better table appearance
            table.set_border_width_on_all_cells(Decimal(0.5))
            table.set_border_color_on_all_cells(X11Color("LightGray"))

            return self._add_element_to_group(table, group, "table", f"Table ({len(data)} rows)")

        except Exception as e:
            raise InvalidInputError(f"An unexpected error occurred while creating the data table. Original error: {str(e)}")

    def add_section_break(self):
        """Adds extra spacing to create a visual section break."""
        self.layout.add(self._create_spacer(self.config["section_spacing"] * 2))

    def export(self, filename: str):
        """
        Saves the report to a PDF file.
        
        This method automatically finalizes any pending groups before saving.

        Args:
            filename: The path to save the PDF file to.
        """
        # Finalize any pending groups
        self.finalize_groups()
        
        with open(filename, "wb") as pdf_file_handle:
            PDF.dumps(pdf_file_handle, self.doc)

    def get_bytes(self) -> bytes:
        """
        Returns the PDF report as a byte string.
        
        This method automatically finalizes any pending groups before returning bytes.
        
        Returns:
            bytes: The PDF content as bytes
        """
        # Finalize any pending groups
        self.finalize_groups()
        
        return PDF.dumps(self.doc)

    def _add_header_logo(self):
        """
        Adds the company logo to the top right corner of the page.
        """
        try:
            # Get the path to the logo file
            logo_path = os.path.join(os.path.dirname(__file__), "img", "short_logo.png")
            
            if os.path.exists(logo_path):
                # Load image using PIL to get dimensions
                from PIL import Image as PILImage
                pil_image = PILImage.open(logo_path)
                
                # Set logo size (small for header)
                logo_width = 18  # Adjusted logo width in points
                aspect_ratio = pil_image.height / pil_image.width
                logo_height = logo_width * aspect_ratio
                
                # Create borb Image
                logo_img = Image(
                    pil_image,
                    width=Decimal(logo_width),
                    height=Decimal(logo_height),
                    horizontal_alignment=Alignment.RIGHT,
                )
                
                # Add debug border if enabled
                if self.config.get("debug_mode", False):
                    if hasattr(logo_img, 'border_color'):
                        logo_img.border_color = HexColor("#ff0000")
                    if hasattr(logo_img, 'border_width'):
                        logo_img.border_width = Decimal(2)
                    if hasattr(logo_img, 'border_top'):
                        logo_img.border_top = True
                        logo_img.border_bottom = True
                        logo_img.border_left = True
                        logo_img.border_right = True
                
                # Create a table to position the logo in the top right
                # This table will have 2 columns: empty space and logo
                from borb.pdf.canvas.layout.table.fixed_column_width_table import FixedColumnWidthTable
                
                header_table = FixedColumnWidthTable(
                    number_of_rows=1,
                    number_of_columns=2,
                    column_widths=[Decimal(0.8), Decimal(0.2)],  # 80% empty, 20% logo
                )
                
                # Add empty cell and logo cell
                header_table.add(Paragraph(""))  # Empty cell
                header_table.add(logo_img)  # Logo cell
                
                # Remove table borders
                header_table.no_borders()
                
                # Add the header table to the layout (this will be at the top)
                self.layout.add(header_table)
                
        except Exception as e:
            # If logo loading fails, continue without logo
            print(f"Note: Could not load company logo: {e}") 

    def create_group(self, name: str) -> ElementGroup:
        """
        Create a new element group that will be kept together on the same page.
        
        Args:
            name: A name for the group (for identification)
            
        Returns:
            ElementGroup: The created group
        """
        group = ElementGroup(name)
        self.groups[name] = group
        return group

    def add_group_to_layout(self, group: ElementGroup):
        """
        Add a group of elements to the layout, attempting to keep them together on the same page.
        
        This implementation tries to estimate if a group will fit on the current page.
        If not, it starts a new page before adding the group.
        
        Args:
            group: The ElementGroup to add to the layout
        """
        if not group.elements:
            return
        
        # For groups with multiple elements, try to keep them together
        if len(group.elements) > 1:
            # Estimate the height needed for this group
            estimated_height = self._estimate_group_height(group)
            
            # Check if we have enough space on current page
            # Be more conservative with remaining space calculation
            current_page_height = 792  # Standard letter height in points
            used_height = self.current_page_elements * 30  # More conservative estimate: 30pt per element
            remaining_height = current_page_height - used_height - 200  # Leave more margin
            
            print(f"🔍 Group '{group.name}': estimated height={estimated_height:.0f}pt, remaining={remaining_height:.0f}pt")
            
            # If group likely won't fit, start a new page
            if estimated_height > remaining_height:
                self._add_page_break()
        
        # Add all elements in the group sequentially
        for element_ref in group.elements:
            self.layout.add(element_ref.element)
            self.current_page_elements += 1

    def _estimate_group_height(self, group: ElementGroup) -> float:
        """
        Estimate the height needed for a group of elements.
        
        This is a more aggressive estimation to better prevent page breaks.
        
        Args:
            group: The ElementGroup to estimate
            
        Returns:
            Estimated height in points
        """
        total_height = 0
        
        for element_ref in group.elements:
            if element_ref.element_type == "title":
                total_height += 35  # More conservative: title height + margins
            elif element_ref.element_type == "header":
                total_height += 30  # More conservative: header height + margins
            elif element_ref.element_type == "paragraph":
                # More aggressive estimation based on text length
                lines = max(2, len(element_ref.content) // 60)  # Shorter line estimate
                total_height += lines * 18  # More space per line
            elif element_ref.element_type == "highlight_box":
                lines = max(2, len(element_ref.content) // 50)  # Even shorter lines in boxes
                total_height += lines * 18 + 20  # More padding for box
            elif element_ref.element_type == "table":
                # More conservative table height estimation
                total_height += 150  # Larger base table height
            elif element_ref.element_type == "image":
                total_height += 200  # Larger default image height estimate
            else:
                total_height += 30  # Larger default element height
        
        # Add extra buffer for the entire group
        total_height += 50  # Group buffer
        
        return total_height

    def _add_page_break(self):
        """
        Add a new page to the document and update the layout.
        """
        # Create a new page
        new_page = Page()
        self.doc.add_page(new_page)
        
        # Track the new page
        self.current_page_number += 1
        self.pages_list.append(new_page)
        
        # Update the layout to use the new page
        self.layout = SingleColumnLayout(new_page)
        
        # Reset element counter for new page
        self.current_page_elements = 0
        
        print(f"📄 Started new page to keep group together")

    def _add_element_to_group(self, element: LayoutElement, group: Optional[ElementGroup], 
                             element_type: str, content: str = "") -> ElementReference:
        """
        Add an element to a group or directly to the layout.
        
        Args:
            element: The borb element to add
            group: Optional group to add the element to
            element_type: Type of element (for reference)
            content: Content description (for reference)
            
        Returns:
            ElementReference: Reference to the added element
        
        Raises:
            InvalidInputError: If the provided group is not valid or was not created by this Report instance.
        """
        element_ref = ElementReference(element, element_type, content)
        
        if group is not None:
            # Validate that the group exists in this report instance
            if group not in self.groups.values():
                raise InvalidInputError(
                    f"Attempted to add element to an unrecognized group: '{group.name}'. "
                    "All ElementGroup objects must be created using the `report.create_group()` method "
                    "before elements can be added to them. This ensures they are properly tracked and rendered."
                )
            # Add to group (don't add to layout yet)
            group.add_element(element_ref)
        else:
            # Add directly to layout
            self.layout.add(element)
            self.current_page_elements += 1
        
        return element_ref

    def _add_page_numbers(self):
        """
        Add page numbers to all pages in the document.
        """
        total_pages = len(self.pages_list)
        
        for page_num, page in enumerate(self.pages_list, 1):
            # Create page number text
            page_text = f"Page {page_num} of {total_pages}"
            
            # Create a page number paragraph
            page_number_paragraph = Paragraph(
                page_text,
                font="Helvetica",
                font_size=Decimal(9),
                font_color=HexColor("#666666"),
                text_alignment=Alignment.CENTERED,
                horizontal_alignment=Alignment.CENTERED
            )
            
            # Use absolute positioning to place the page number at the bottom
            from borb.pdf.canvas.geometry.rectangle import Rectangle
            
            # Position at bottom center of page with proper margins
            page_width = Decimal(595)  # A4 page width
            margin = Decimal(72)       # 1 inch margins
            content_width = page_width - (2 * margin)  # Content area width
            
            footer_rect = Rectangle(
                margin,        # x position (left margin)
                Decimal(30),   # y position (30pt from bottom)
                content_width, # width (content area width)
                Decimal(20)    # height
            )
            
            # Add the page number using absolute positioning
            try:
                # Try to use the layout method if available
                page_number_paragraph.paint(page, footer_rect)
            except AttributeError:
                # Fallback: add to a temporary layout (this might not position correctly)
                temp_layout = SingleColumnLayout(page)
                # Add some spacing to push content to bottom
                for _ in range(30):  # Add spacers to push to bottom
                    temp_layout.add(Paragraph("", font_size=Decimal(1)))
                temp_layout.add(page_number_paragraph)

    def finalize_groups(self):
        """
        Finalize all groups by adding them to the layout.
        Call this method after creating all your groups and before saving the PDF.
        """
        for group in self.groups.values():
            if group.elements:  # Only process groups that have elements
                self.add_group_to_layout(group)
        
        # Add page numbers to all pages
        self._add_page_numbers() 