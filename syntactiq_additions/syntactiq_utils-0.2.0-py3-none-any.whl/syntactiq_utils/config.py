"""Configuration management for database connections."""

import os
from typing import Optional, Dict

from .exceptions import ConnectionError
from .fonts import get_default_font_path


def _get_duckdb_file_path() -> str:
    """
    Retrieves the DuckDB file path from environment variables.

    Returns:
        The path to the DuckDB file.

    Raises:
        ConnectionError: If the DUCKDB_FILE_PATH environment variable is not set
                         or if the file does not exist.
    """
    file_path = os.environ.get("DUCKDB_FILE_PATH")
    
    if file_path is None:
        error_msg = (
            "❌ ERROR: Missing required environment variable 'DUCKDB_FILE_PATH'.\n"
            "   Please set it to the path of your duck.db file.\n"
            "   Example: export DUCKDB_FILE_PATH=/path/to/duck.db"
        )
        print(error_msg)
        raise ConnectionError(
            "Missing required environment variable: DUCKDB_FILE_PATH. "
            "Please set the path to your duck.db file."
        )
    
    if not os.path.exists(file_path):
        error_msg = (
            f"❌ ERROR: DuckDB file not found at path: {file_path}\n"
            f"   Please ensure the file exists and the path is correct.\n"
            f"   Current DUCKDB_FILE_PATH: {file_path}"
        )
        print(error_msg)
        raise ConnectionError(
            f"DuckDB file not found at path: {file_path}. "
            "Please ensure the file exists and the path is correct."
        )
    
    return file_path


def get_report_config() -> Dict:
    """
    Provides a standardized configuration for PDF report styling.
    Following scientific publication best practices for typography and layout.

    Returns:
        A dictionary containing styling parameters for fonts, colors,
        margins, and spacing optimized for academic/scientific documents.
    """
    return {
        # Font paths - using embedded DIN Next fonts
        "font_family": get_default_font_path("body") or "Helvetica",
        "font_family_bold": get_default_font_path("body_bold") or "Helvetica-Bold",
        "font_family_heading": get_default_font_path("heading") or "Helvetica-Bold",
        "font_family_title": get_default_font_path("title") or "Helvetica-Bold",
        "font_family_caption": get_default_font_path("caption") or "Helvetica",
        
        # Font sizes - organized in nested dictionary
        "font_sizes": {
            "title": 16,    # More conservative for scientific papers
            "heading": 14,  # Section headings
            "body": 11,     # Standard academic body text
            "table": 9,     # Smaller for data tables
            "caption": 9,   # Figure/table captions
        },
        
        # Colors - organized in nested dictionary
        "colors": {
            "text": "#2d3748",           # Main text color (dark grey)
            "primary": "#2d3748",        # Dark grey for headings (not pure black)
            "secondary": "#4a5568",      # Medium grey for body text
            "accent": "#f7fafc",         # Very light grey for backgrounds
            "highlight": "#F5AF00",      # Corporate color for highlight boxes
            "table_header": "#2d3748",   # Dark grey header
            "table_header_text": "#ffffff", # White text on dark header
            "table_border": "#cbd5e0",   # Light grey borders
            "table_alt_row": "#f7fafc",  # Very subtle alternating rows
        },
        
        # Layout - 1 inch margins (72pt = 1 inch) for academic standards
        "page_margin_top": 72,     # 1 inch margins (72pt = 1 inch)
        "page_margin_right": 72,   # Standard academic margins
        "page_margin_bottom": 72,  # Consistent all around
        "page_margin_left": 72,    # Professional appearance
        
        # Spacing - extremely tight for academic look
        "vertical_spacing": 1,     # Minimal spacing between elements
        "section_spacing": 3,      # Very minimal section breaks
        "title_spacing": 4,        # Very minimal space after main title
        "table_padding": 4,        # Compact table padding
        "border_width": 0.5,       # Subtle borders
        "hint_box_padding": 10,    # Compact callout boxes
        "line_height_multiplier": 1.2,  # Academic line spacing (not double)
        
        # Debug settings
        "debug_mode": False,       # Show borders around elements for debugging
    } 