"""
This module contains a detailed instruction string for an LLM on how to
use the syntactiq_utils package effectively.
"""

LLM_INSTRUCTIONS = """
# Guide: Using the `syntactiq_utils` High-Performance Package

## 1. General Idea & Purpose

This package is your primary tool for accessing and analyzing data from a pre-existing DuckDB database file.
It is designed for **maximum performance and memory efficiency** by providing a streamlined interface
to DuckDB's powerful analytical capabilities.

**Your primary workflow should always be:**
1.  Connect to the DuckDB database file. The file path is configured via environment variables.
2.  Explore what tables are available (`explore_tables`).
3.  Examine table schemas and preview data (`get_table_schema`, `preview_data`).
4.  Perform all your transformations, filtering, and aggregations using `create_table_from_query` and `query`.
5.  Use `table_to_df` to return final result sets to pandas DataFrame for further analysis.

**A Note on SQL Dialects:** All queries use **DuckDB's SQL dialect**, which provides excellent performance
for analytical workloads and supports most standard SQL features.

---

## 2. Core Methods and Their Purpose

### Connection
-   `connect(memory_limit_gb: Optional[float] = None, thread_percentage: float = 30.0, log_level: str = "info") -> SyntactiqDB`: Establishes the connection to the DuckDB file.
    -   `memory_limit_gb`: Optional. Sets a memory limit for DuckDB. If not provided, it intelligently defaults to 30% of your total system RAM. There is a hard cap of 80% of system RAM or 32GB, whichever is smaller.
    -   `thread_percentage`: Optional. Sets the percentage of CPU cores for DuckDB to use. Defaults to 30%, capped at 70%.
    -   `log_level`: Set to 'debug' for verbose, detailed logging. Defaults to 'info'.
-   `health_check() -> dict`: Verifies that the connection is live.
-   `close(db: SyntactiqDB)`: Closes the connection and releases resources. This should be your final step.

### Exploration & Previewing (Low, Safe Limits)
-   `explore_tables(db: SyntactiqDB) -> pd.DataFrame`: Shows you what tables exist in the DuckDB database.
-   `get_table_schema(db: SyntactiqDB, table_name: str, display_rows: int = 100) -> str`: Shows you the structure and sample rows of a table.
-   `preview_data(db: SyntactiqDB, sql_query: str, limit: int = 100) -> pd.DataFrame`: Runs a query with a hard limit of **100 rows** for quick data exploration.
-   `show_table(db: SyntactiqDB, table_name: str, n: int = 500_000) -> pd.DataFrame`: A quick way to see the first few rows of a table.

### Transformation & Data Retrieval (High, Safety-Monitored Limits)
-   `create_table_from_query(db: SyntactiqDB, new_table_name: str, sql_query: str)`: Creates a new table from a SQL query. No row limits.
-   `query(db: SyntactiqDB, sql_query: str, limit: Optional[int] = 500_000) -> pd.DataFrame`: The main engine for running queries. Hard safety limit of **500,000 rows**.
-   `table_to_df(db: SyntactiqDB, table_name: str, limit: int = 500_000) -> pd.DataFrame`: Converts a DuckDB table to a pandas DataFrame. Hard safety limit of **500,000 rows**.

---

## 3. Best-Practice Workflow Example

This example shows how you would typically work in a multi-cell Jupyter notebook.

#### Cell 1: Connect
```python
from syntactiq_utils import *

# Create the connection object. It will stay live across cells.
# Make sure DUCKDB_FILE_PATH environment variable is set
db = connect()

# Now you can use 'db' in subsequent cells.
```

#### Cell 2: Explore
```python
# 1. Discover what's available
print("--- Exploring Tables ---")
print(explore_tables(db))

# 2. Examine a specific table structure
print("\\n--- Users Table Schema ---")
print(get_table_schema(db, "users", display_rows=3))
```

#### Cell 3: Query and Transform
```python
# 3. Preview data with a quick query
print("\\n--- Latest Users Preview ---")
print(preview_data(db, "SELECT * FROM users ORDER BY created_at DESC", limit=5))

# 4. Create a new table with complex analysis
create_table_from_query(
    db,
    "german_users_summary",
    \"\"\"
    SELECT 
        country,
        COUNT(*) as user_count,
        AVG(age) as avg_age
    FROM users 
    WHERE country = 'DE'
    GROUP BY country
    \"\"\"
)

# 5. Explore what tables we now have
print("\\n--- Updated Table List ---")
print(explore_tables(db))
```

#### Cell 4: Final Analysis and Export
```python
# 6. Export the final result to a pandas DataFrame
print("\\n--- Final Analysis ---")
final_df = table_to_df(db, "german_users_summary")
print(final_df)

# Or run a direct query for immediate results
result_df = query(db, "SELECT * FROM users WHERE country = 'DE' LIMIT 100")
print(result_df.head())
```

#### Cell 5: Close the Connection
```python
# When you are finished with your analysis, close the connection to release resources.
close(db)
```""" 

REPORTING_INSTRUCTIONS = """
# Guide: Generating PDF Reports with `syntactiq_utils.Report`

## 1. Core Concept & Workflow

The `Report` class creates high-quality, professionally styled PDF documents. Your workflow is:

1.  **Initialize**: `report = Report(title="My Report", author="Me")`
2.  **Add Content**: Use `add_*` methods like `add_title`, `add_header`, `add_paragraph`, etc.
3.  **Group Elements**: Use `report.create_group()` to keep related content together and prevent bad page breaks. This is critical for professional layouts.
4.  **Export**: `report.export("final_report.pdf")`

---

## 2. Core Methods

-   `Report(author: str, title: str)`: Creates a new report.
-   `add_title(text: str)`: Adds a main title. Use once at the start.
-   `add_header(text: str)`: Adds a section header.
-   `add_paragraph(text: str)`: Adds a paragraph. Supports `\\n` for new lines.
-   `add_highlight_box(type_text: str, content: str)`: Creates an italicized call-out box for key insights or recommendations.
-   `add_data_table(data: pd.DataFrame)`: Renders a pandas DataFrame as a styled, centered table.
-   `add_image(image_path: str, max_height: float)`: Adds an image, scaled proportionally to a max height.
-   `add_section_break()`: Inserts vertical space to separate major sections.
-   `export(filename: str)`: Saves the report to a PDF file.

---

## 3. The Grouping System (Essential for Layout Control)

To ensure related items (like a header and its table) stay on the same page, use grouping.

```python
# 1. Create a group
my_group = report.create_group("group_name_for_debug")

# 2. Add elements to the group
report.add_header("Sales Data", group=my_group)
report.add_data_table(my_dataframe, group=my_group)

# The layout engine will now keep these two elements together, adding a
# page break automatically if they won't fit on the current page.
```

---

## 4. Best-Practice Example

This example demonstrates a typical report structure.

```python
from syntactiq_utils import Report
import pandas as pd
import os

# --- 1. Setup ---
report = Report(author="Analytics Dept.", title="Monthly Review")
df = pd.DataFrame({'Region': ['North', 'West'], 'Sales': ['$150K', '$225K']})

# --- 2. Add Title ---
report.add_title("Monthly Performance Review - August 2024")

# --- 3. Create Grouped Section ---
summary_group = report.create_group("executive_summary")
report.add_header("1. Executive Summary", group=summary_group)
report.add_paragraph(
    "This month saw a significant uptick in sales, particularly in the West region.",
    group=summary_group
)
report.add_highlight_box(
    "Key Insight", "The West region's growth is a new record.", group=summary_group
)

# --- 4. Create Another Grouped Section ---
table_group = report.create_group("sales_data")
report.add_header("2. Regional Sales Data", group=table_group)
report.add_data_table(df, group=table_group)

# --- 5. Add Image ---
report.add_header("3. Sales Growth Chart")
try:
    # Assumes 'sample_chart.png' exists
    report.add_image(os.path.abspath("sample_chart.png"), max_height=250)
except Exception:
    report.add_paragraph("(Chart image not found.)")

# --- 6. Export ---
report.export("monthly_review.pdf")
print("Report 'monthly_review.pdf' generated.")
```
"""


