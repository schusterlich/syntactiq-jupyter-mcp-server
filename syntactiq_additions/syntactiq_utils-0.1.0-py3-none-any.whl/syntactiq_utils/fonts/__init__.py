"""
Font management for Syntactiq Utils.

This module provides access to embedded fonts for use in PDF reports.
"""

import os
from pathlib import Path
from typing import Dict, Optional

# Get the directory where font files are stored
FONTS_DIR = Path(__file__).parent

# Font file mappings
FONT_FILES = {
    "DINNext-UltraLight": "dinnextw1g_ultralight.otf",
    "DINNext-UltraLightItalic": "dinnextw1g_ultralightitalic.otf",
    "DINNext-Light": "dinnextw1g_light.otf",
    "DINNext-LightItalic": "dinnextw1g_lightitalic.otf",
    "DINNext-Regular": "dinnextw1g.otf",
    "DINNext-Italic": "dinnextw1g_italic.otf",
    "DINNext-Medium": "dinnextw1g_medium.otf",
    "DINNext-MediumItalic": "dinnextw1g_mediumitalic.otf",
    "DINNext-Bold": "dinnextw1g_bold.otf",
    "DINNext-BoldItalic": "dinnextw1g_bolditalic.otf",
    "DINNext-Heavy": "dinnextw1g_heavy.otf",
    "DINNext-HeavyItalic": "dinnextw1g_heavyitalic.otf",
    "DINNext-Black": "dinnextw1g_black.otf",
    "DINNext-BlackItalic": "dinnextw1g_blackitalic.otf",
}


def get_font_path(font_name: str) -> Optional[str]:
    """
    Get the full path to a font file.
    
    Args:
        font_name: Name of the font (e.g., 'DINNext-Regular')
        
    Returns:
        Full path to the font file, or None if not found
    """
    if font_name not in FONT_FILES:
        return None
    
    font_file = FONT_FILES[font_name]
    font_path = FONTS_DIR / font_file
    
    if font_path.exists():
        return str(font_path)
    
    return None


def get_available_fonts() -> Dict[str, str]:
    """
    Get a dictionary of all available fonts and their file paths.
    
    Returns:
        Dictionary mapping font names to file paths
    """
    available = {}
    for font_name, font_file in FONT_FILES.items():
        font_path = FONTS_DIR / font_file
        if font_path.exists():
            available[font_name] = str(font_path)
    
    return available


def get_font_for_borb(font_name: str) -> Optional[str]:
    """
    Get a font path suitable for use with borb PDF library.
    
    Args:
        font_name: Name of the font
        
    Returns:
        Font path or None if not available
    """
    return get_font_path(font_name)


# Default fonts for different use cases
DEFAULT_FONTS = {
    "body": "DINNext-Regular",
    "body_bold": "DINNext-Medium", 
    "heading": "DINNext-Medium",
    "heading_bold": "DINNext-Bold",
    "title": "DINNext-Bold",
    "caption": "DINNext-Light",
}


def get_default_font_path(font_type: str) -> Optional[str]:
    """
    Get the path for a default font type.
    
    Args:
        font_type: Type of font ('body', 'heading', 'title', etc.)
        
    Returns:
        Font path or None if not available
    """
    if font_type not in DEFAULT_FONTS:
        return None
    
    font_name = DEFAULT_FONTS[font_type]
    return get_font_path(font_name)


def load_fonts() -> Dict[str, str]:
    """
    Load all available fonts for use in PDF generation.
    
    Returns:
        Dictionary mapping font types to font objects or font names
    """
    from borb.pdf.canvas.font.simple_font.true_type_font import TrueTypeFont
    
    fonts = {}
    
    # Try to load custom DIN Next fonts
    for font_type, font_name in DEFAULT_FONTS.items():
        font_path = get_font_path(font_name)
        
        if font_path and os.path.exists(font_path):
            try:
                # Load custom font
                fonts[font_type] = TrueTypeFont.true_type_font_from_file(font_path)
            except Exception:
                # Fall back to system font names
                fonts[font_type] = _get_fallback_font(font_type)
        else:
            # Use system font names as fallback
            fonts[font_type] = _get_fallback_font(font_type)
    
    return fonts


def _get_fallback_font(font_type: str) -> str:
    """Get fallback system font name for a given font type."""
    fallbacks = {
        "body": "Helvetica",
        "body_bold": "Helvetica-Bold", 
        "heading": "Helvetica-Bold",
        "heading_bold": "Helvetica-Bold",
        "title": "Helvetica-Bold",
        "caption": "Helvetica",
    }
    return fallbacks.get(font_type, "Helvetica") 