"""
This module contains a detailed instruction string for an LLM on how to
use the syntactiq_utils package effectively.
"""

LLM_INSTRUCTIONS = """
# Guide: Using the `syntactiq_utils` High-Performance Package

## 1. General Idea & Purpose

This package is your primary tool for accessing and analyzing our PostgreSQL database.
It is designed for **maximum performance and memory efficiency** by creating a
direct link between an in-memory DuckDB instance and the remote PostgreSQL database.

**Your primary workflow should always be:**
1.  Connect to the database environment. This automatically `ATTACH`es PostgreSQL.
2.  Explore what tables are available (`explore_remote_tables`, `explore_local_tables`).
3.  Load the specific table(s) you need into DuckDB's memory using `load_table`. This is a highly efficient, direct data transfer.
4.  Perform all your transformations, filtering, and aggregations using `create_table_from_query`. This keeps all large data operations within the DuckDB engine.
5.  Use preview functions (`preview_remote_data`, `preview_local_data`, `show_table`) for quick, safe checks.
6.  Use `query` or `table_to_df` to return final, medium-sized result sets to a pandas DataFrame.

**A Note on SQL Dialects:** All queries run through this package use **DuckDB's SQL dialect**. DuckDB is largely compatible with PostgreSQL, so most of your queries will work as expected.

---

## 2. Core Methods and Their Purpose

### Connection
-   `connect(schema: str = 'public', memory_limit_gb: Optional[float] = None, thread_percentage: float = 30.0, log_level: str = "info") -> SyntactiqDB`: Establishes the connection.
    -   `schema`: Use if you need to target a schema other than 'public'.
    -   `memory_limit_gb`: Optional. Sets a memory limit for DuckDB. If not provided, it intelligently defaults to 30% of your total system RAM. There is a hard cap of 80% of system RAM or 32GB, whichever is smaller.
    -   `thread_percentage`: Optional. Sets the percentage of CPU cores for DuckDB to use. Defaults to 30%, capped at 70%.
    -   `log_level`: Set to 'debug' for verbose, detailed logging. Defaults to 'info'.
-   `health_check() -> dict`: Verifies that the connection is live.
-   `close(db: SyntactiqDB)`: Closes the connection and releases resources. This should be your final step.

### Exploration & Previewing (Low, Safe Limits)
-   `explore_remote_tables(db: SyntactiqDB, schema: str = "public") -> pd.DataFrame`: Shows you what tables exist in the main PostgreSQL database.
-   `get_remote_table_schema(db: SyntactiqDB, table_name: str, schema: str = "public", display_rows: int = 3) -> str`: Shows you the structure and 3 sample rows of a PostgreSQL table.
-   `preview_remote_data(db: SyntactiqDB, sql_query: str, limit: int = 10) -> pd.DataFrame`: Runs a **read-only** query on PostgreSQL. Hard limit of **100 rows**.
-   `explore_local_tables(db: SyntactiqDB) -> pd.DataFrame`: Shows you what tables you have created in your local DuckDB session.
-   `get_local_table_schema(db: SyntactiqDB, table_name: str, display_rows: int = 3) -> str`: Shows you the structure and 3 sample rows of a local DuckDB table.
-   `preview_local_data(db: SyntactiqDB, sql_query: str, limit: int = 100) -> pd.DataFrame`: Runs a query on your local DuckDB data. Hard limit of **100 rows**.
-   `show_table(db: SyntactiqDB, table_name: str, n: int = 5) -> pd.DataFrame`: A quick way to see the first few rows of a local table.

### Transformation & Data Retrieval (High, Safety-Monitored Limits)
-   `load_table(db: SyntactiqDB, source_table_name: str, dest_table_name: Optional[str] = None, columns: str = "*", where_clause: Optional[str] = None, limit: Optional[int] = None)`: Copies data from PostgreSQL into a local DuckDB table.
    -   **Performance Tip:** To load large tables faster, use the `columns`, `where_clause`, and `limit` parameters to only transfer the data you need.
-   `create_table_from_query(db: SyntactiqDB, new_table_name: str, sql_query: str)`: Creates a new local table from a SQL query. No row limits.
-   `query(db: SyntactiqDB, sql_query: str, limit: Optional[int] = 1000) -> pd.DataFrame`: The main engine for running queries on your local DuckDB data. Hard safety limit of **500,000 rows**.
-   `table_to_df(db: SyntactiqDB, table_name: str, limit: int = 1000) -> pd.DataFrame`: Converts a local DuckDB table to a pandas DataFrame. Hard safety limit of **500,000 rows**.

---

## 3. Best-Practice Workflow Example

This example shows how you would typically work in a multi-cell Jupyter notebook.

#### Cell 1: Connect
```python
from syntactiq_utils.data import *

# Create the connection object. It will stay live across cells.
db = connect()

# Now you can use 'db' in subsequent cells.
```

#### Cell 2: Explore
```python
# 1. Discover what's available
print("--- Exploring Remote Tables ---")
print(explore_remote_tables(db))

# 2. Peek at remote data before committing to a full load
print("\\n--- Previewing Remote Users ---")
print(preview_remote_data(db, "SELECT * FROM users ORDER BY created_at DESC", limit=3))
```
#### Cell 3: Load and Transform
```python
# 3. Load a filtered subset of the 'users' table into a local table
print("\\n--- Loading German Users (only specific columns) ---")
load_table(
    db,
    source_table_name="users",
    dest_table_name="german_users_emails",
    columns="user_id, secret_key",
    where_clause="country = 'DE'"
)

# 4. Explore and inspect the new local table
print("\\n--- Exploring Local Tables ---")
print(explore_local_tables(db))
```
#### Cell 4: Final Analysis and Export
```python
# 5. Export the final, small result set to a pandas DataFrame
print("\\n--- Exporting Final Result ---")
final_df = table_to_df(db, "german_users_emails")
print(final_df)
```

#### Cell 5: Close the Connection
```python
# When you are finished with your analysis, close the connection to release resources.
close(db)
```""" 

REPORTING_INSTRUCTIONS = """
# Guide: Generating PDF Reports with `syntactiq_utils.Report`

## 1. Core Concept & Workflow

The `Report` class creates high-quality, professionally styled PDF documents. Your workflow is:

1.  **Initialize**: `report = Report(title="My Report", author="Me")`
2.  **Add Content**: Use `add_*` methods like `add_title`, `add_header`, `add_paragraph`, etc.
3.  **Group Elements**: Use `report.create_group()` to keep related content together and prevent bad page breaks. This is critical for professional layouts.
4.  **Export**: `report.export("final_report.pdf")`

---

## 2. Core Methods

-   `Report(author: str, title: str)`: Creates a new report.
-   `add_title(text: str)`: Adds a main title. Use once at the start.
-   `add_header(text: str)`: Adds a section header.
-   `add_paragraph(text: str)`: Adds a paragraph. Supports `\\n` for new lines.
-   `add_highlight_box(type_text: str, content: str)`: Creates an italicized call-out box for key insights or recommendations.
-   `add_data_table(data: pd.DataFrame)`: Renders a pandas DataFrame as a styled, centered table.
-   `add_image(image_path: str, max_height: float)`: Adds an image, scaled proportionally to a max height.
-   `add_section_break()`: Inserts vertical space to separate major sections.
-   `export(filename: str)`: Saves the report to a PDF file.

---

## 3. The Grouping System (Essential for Layout Control)

To ensure related items (like a header and its table) stay on the same page, use grouping.

```python
# 1. Create a group
my_group = report.create_group("group_name_for_debug")

# 2. Add elements to the group
report.add_header("Sales Data", group=my_group)
report.add_data_table(my_dataframe, group=my_group)

# The layout engine will now keep these two elements together, adding a
# page break automatically if they won't fit on the current page.
```

---

## 4. Best-Practice Example

This example demonstrates a typical report structure.

```python
from syntactiq_utils import Report
import pandas as pd
import os

# --- 1. Setup ---
report = Report(author="Analytics Dept.", title="Monthly Review")
df = pd.DataFrame({'Region': ['North', 'West'], 'Sales': ['$150K', '$225K']})

# --- 2. Add Title ---
report.add_title("Monthly Performance Review - August 2024")

# --- 3. Create Grouped Section ---
summary_group = report.create_group("executive_summary")
report.add_header("1. Executive Summary", group=summary_group)
report.add_paragraph(
    "This month saw a significant uptick in sales, particularly in the West region.",
    group=summary_group
)
report.add_highlight_box(
    "Key Insight", "The West region's growth is a new record.", group=summary_group
)

# --- 4. Create Another Grouped Section ---
table_group = report.create_group("sales_data")
report.add_header("2. Regional Sales Data", group=table_group)
report.add_data_table(df, group=table_group)

# --- 5. Add Image ---
report.add_header("3. Sales Growth Chart")
try:
    # Assumes 'sample_chart.png' exists
    report.add_image(os.path.abspath("sample_chart.png"), max_height=250)
except Exception:
    report.add_paragraph("(Chart image not found.)")

# --- 6. Export ---
report.export("monthly_review.pdf")
print("Report 'monthly_review.pdf' generated.")
```
"""


