"""Syntactiq Utils: A Python package for efficient database access and analysis."""

from .data import (
    connect,
    explore_remote_tables,
    get_remote_table_schema,
    explore_local_tables,
    get_local_table_schema,
    load_table,
    create_table_from_query,
    query,
    preview_remote_data,
    preview_local_data,
    show_table,
    table_to_df,
    health_check,
    close,
)
from .exceptions import SyntactiqException
from .llm_docs import LLM_INSTRUCTIONS
from .reporting import Report

__all__ = [
    "connect",
    "explore_remote_tables",
    "get_remote_table_schema",
    "explore_local_tables",
    "get_local_table_schema",
    "load_table",
    "create_table_from_query",
    "query",
    "preview_remote_data",
    "preview_local_data",
    "show_table",
    "table_to_df",
    "health_check",
    "close",
    "SyntactiqException",
    "LLM_INSTRUCTIONS",
    "Report",
] 