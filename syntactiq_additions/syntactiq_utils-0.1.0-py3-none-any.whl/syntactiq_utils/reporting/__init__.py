"""Syntactiq-Utils Reporting Subpackage."""

from .report import Report

__all__ = ["Report"]
