"""Syntactiq-Utils Data Subpackage."""

from .core import (
    SyntactiqDB,
    connect,
    close,
    create_table_from_query,
    explore_local_tables,
    explore_remote_tables,
    get_local_table_schema,
    get_remote_table_schema,
    health_check,
    load_table,
    preview_local_data,
    preview_remote_data,
    query,
    show_table,
    table_to_df,
) 