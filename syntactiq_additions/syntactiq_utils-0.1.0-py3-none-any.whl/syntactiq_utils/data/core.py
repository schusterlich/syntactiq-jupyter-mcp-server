"""Core functionalities for the Syntactiq Utils package."""

import duckdb
import pandas as pd
from typing import Optional
import re
import time
import multiprocessing
import psutil
from sqlalchemy import create_engine, text

from ..config import get_postgres_connection_string
from ..exceptions import ConnectionError, QueryError, TableNotFound


class SyntactiqDB:
    """
    A database connection manager that uses DuckDB to accelerate PostgreSQL queries.
    It works by attaching a remote PostgreSQL database directly to an in-memory
    DuckDB instance, allowing for high-performance data transfer and querying.
    """

    def __init__(self, schema: str = 'public', memory_limit_gb: Optional[float] = None, thread_percentage: float = 30.0, log_level: str = "info"):
        """
        Initializes the SyntactiqDB instance, establishes a connection to DuckDB,
        and attaches the PostgreSQL database.
        """
        self.conn = None
        self.schema = schema
        self.log_level = log_level
        try:
            self._log("🚀 Initializing DuckDB connection...")
            self.conn = duckdb.connect(database=":memory:")
            self._log("✅ DuckDB in-memory database established.", level="info")

            # Set intelligent, system-aware memory limit
            self._set_memory_limit(memory_limit_gb)
            
            self._set_threads(percentage=thread_percentage)

            self._log("📦 Installing and loading PostgreSQL extension...")
            self.conn.execute("INSTALL postgres_scanner;")
            self.conn.execute("LOAD postgres_scanner;")
            self._log("✅ PostgreSQL extension loaded.")

            self._log("🔗 Attaching PostgreSQL database...")
            pg_conn_string = get_postgres_connection_string()
            self.conn.execute(f"ATTACH '{pg_conn_string}' AS pg (TYPE POSTGRES, READ_ONLY)")
            self._log("✅ PostgreSQL database attached as 'pg'.")

            # Test the connection to ensure it's healthy
            self.conn.execute("SELECT 1 FROM pg.information_schema.tables LIMIT 1;")
            self._log("✅ Connection to PostgreSQL appears healthy.", level="info")

        except Exception as e:
            self.close()
            raise ConnectionError(f"Failed to initialize database connection: {e}") from e

    def close(self):
        """Closes the DuckDB connection and detaches the PostgreSQL database."""
        if self.conn:
            try:
                self.conn.execute("DETACH pg")
                self._log("✅ PostgreSQL database detached.")
            except duckdb.Error:
                pass
            finally:
                self.conn.close()
                self.conn = None
                self._log("✅ DuckDB connection closed.")

    def __enter__(self):
        """Enter the runtime context related to this object."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit the runtime context related to this object."""
        self.close()

    def _log(self, message: str, level: str = "debug"):
        """Internal logging helper."""
        if self.log_level == "debug" or level == "info":
            print(message)

    def _set_memory_limit(self, memory_limit_gb: Optional[float]):
        """
        Sets a system-aware memory limit for DuckDB.
        """
        total_system_memory_gb = psutil.virtual_memory().total / (1024 ** 3)
        
        # Calculate hard cap: 80% of system RAM or 32GB, whichever is smaller.
        hard_cap_gb = min(total_system_memory_gb * 0.8, 32.0)

        limit_to_set_gb: float

        if memory_limit_gb is None:
            # Default logic: 30% of system RAM.
            default_limit_gb = total_system_memory_gb * 0.3
            limit_to_set_gb = min(default_limit_gb, hard_cap_gb)
            self._log(f"✅ No memory limit provided. Setting a default of {limit_to_set_gb:.2f}GB (30% of system memory).")
        else:
            # User-provided logic
            if memory_limit_gb > hard_cap_gb:
                self._log(f"⚠️  Warning: Requested memory limit of {memory_limit_gb:.2f}GB exceeds the cap. "
                      f"Setting to {hard_cap_gb:.2f}GB.", level="info")
                limit_to_set_gb = hard_cap_gb
            else:
                limit_to_set_gb = memory_limit_gb

        self._log(f"🔧 Setting memory limit to {limit_to_set_gb:.2f}GB...")
        if self.conn:
            self.conn.execute(f"PRAGMA memory_limit='{limit_to_set_gb:.2f}GB'")
        self._log(f"✅ Memory limit set.")

    def _set_threads(self, percentage: float):
        """
        Set DuckDB to use a specified percentage of available CPU threads.
        """
        THREAD_HARD_CAP_PERCENT = 70.0
        
        if not (0 < percentage <= 100):
            self._log(f"⚠️ Warning: Invalid thread percentage {percentage}. Using default of 30%.", level="info")
            percentage = 30.0

        if percentage > THREAD_HARD_CAP_PERCENT:
            self._log(f"⚠️  Warning: Requested thread percentage of {percentage}% exceeds the hard cap. "
                  f"Capping at {THREAD_HARD_CAP_PERCENT}%.", level="info")
            percentage = THREAD_HARD_CAP_PERCENT
        
        num_cores = multiprocessing.cpu_count()
        num_threads = max(1, round((percentage / 100) * num_cores))
        if self.conn:
            self.conn.execute(f"PRAGMA threads={num_threads}")
        self._log(f"✅ DuckDB threads set to {num_threads} ({percentage:.1f}% of {num_cores} cores).")


def connect(
    schema: str = 'public', 
    memory_limit_gb: Optional[float] = None,
    thread_percentage: float = 30.0,
    log_level: str = "info"
) -> SyntactiqDB:
    """
    Establishes a connection to the databases.

    Args:
        schema: The PostgreSQL schema to target. Defaults to 'public'.
        memory_limit_gb: Optional. The memory limit for DuckDB in Gigabytes.
                         It is capped at a hard limit of 10GB.
        thread_percentage: Optional. The percentage of CPU cores to use for DuckDB.
                           Defaults to 30%, capped at 70%.
        log_level: The logging verbosity. Can be 'info' (default) or 'debug'.
    """
    return SyntactiqDB(
        schema=schema, 
        memory_limit_gb=memory_limit_gb, 
        thread_percentage=thread_percentage,
        log_level=log_level
    )


def _get_postgres_engine():
    """Creates a new SQLAlchemy engine for PostgreSQL."""
    try:
        pg_conn_string = get_postgres_connection_string()
        return create_engine(pg_conn_string)
    except Exception as e:
        raise ConnectionError(f"Failed to create PostgreSQL engine: {e}") from e


def explore_remote_tables(db: SyntactiqDB) -> pd.DataFrame:
    """
    Lists all tables, views, and materialized views in the connected PostgreSQL schema
    for which the current user has SELECT permissions. Also provides an estimated row count.
    """
    if not db.conn:
        raise ConnectionError("DuckDB connection is not available.")

    # This query runs on a direct PostgreSQL connection to reliably check permissions
    # and get estimated row counts for tables.
    sql = text(f"""
        WITH all_tables AS (
            SELECT table_name, 'BASE TABLE' AS table_type FROM information_schema.tables WHERE table_schema = :schema
            UNION ALL
            SELECT table_name, 'VIEW' AS table_type FROM information_schema.views WHERE table_schema = :schema
            UNION ALL
            SELECT matviewname AS table_name, 'MATERIALIZED VIEW' AS table_type FROM pg_catalog.pg_matviews WHERE schemaname = :schema
        )
        SELECT 
            t.table_name, 
            t.table_type,
            c.reltuples::bigint AS estimated_rows
        FROM all_tables t
        LEFT JOIN pg_catalog.pg_class c ON c.relname = t.table_name
        WHERE has_table_privilege(t.table_name::text, 'SELECT')
        ORDER BY t.table_name;
    """)
    try:
        db._log(f"🔎 Exploring accessible tables, views, and materialized views in remote schema '{db.schema}'...")
        engine = _get_postgres_engine()
        with engine.connect() as connection:
            accessible_tables_df = pd.read_sql_query(sql, connection, params={"schema": db.schema})
        
        db._log(f"✅ Found {len(accessible_tables_df)} accessible tables.", level="info")
        return accessible_tables_df
        
    except Exception as e:
        raise QueryError(f"Failed to explore remote tables. Error: {e}") from e


def get_remote_table_schema(db: SyntactiqDB, table_name: str, display_rows: int = 100) -> str:
    """
    Returns a description of a table from PostgreSQL, including columns, types, and sample rows.
    """
    table_ref = f"pg.{db.schema}.{table_name}"
    try:
        db._log(f"📄 Describing schema for remote table '{table_name}'...")
        columns_df = query(db, f"DESCRIBE {table_ref};", limit=None)
        if columns_df.empty:
            raise TableNotFound(f"Table '{db.schema}.{table_name}' not found in remote PostgreSQL database.")

        db._log(f" échantillon... (Fetching {display_rows} sample rows from remote table)...")
        sample_rows_df = query(db, f"SELECT * FROM {table_ref} LIMIT {display_rows}")
        
        description = f"Remote Table: {db.schema}.{table_name}\\n\\n"
        description += "Columns:\\n"
        description += columns_df[["column_name", "column_type"]].to_string(index=False)
        description += f"\\n\\nSample Rows ({display_rows} rows):\\n"
        description += sample_rows_df.to_string(index=False)
        
        db._log("✅ Successfully generated remote table description.", level="info")
        return description
    except Exception as e:
        raise QueryError(f"Failed to get remote schema for table '{table_name}'. Hint: get_remote_table_schema runs on DuckDB. Error: {e}") from e


def preview_remote_data(db: SyntactiqDB, sql_query: str, limit: int = 100) -> pd.DataFrame:
    """
    Executes a read-only SQL query directly against the remote PostgreSQL database
    for a quick preview of the data.
    """
    REMOTE_PREVIEW_HARD_LIMIT = 100
    final_query = sql_query.strip().rstrip(';')

    if re.search(r'limit\s+\d+\s*$', final_query, re.IGNORECASE):
        raise QueryError("Query rejected. Do not include a 'LIMIT' clause in `preview_remote_data`.")

    # Use a regex to robustly add the pg.public prefix to tables in FROM or JOIN clauses
    # This pattern looks for 'from' or 'join', optional whitespace, and captures the table name.
    # It avoids prefixing if 'pg.public' is already present.
    def add_prefix_if_needed(match):
        keyword = match.group(1)
        table_name = match.group(2)
        full_match = match.group(0)
        
        # Check if the table is already prefixed
        # This is a bit simplistic, as it checks the whole query, but good enough for this context.
        if f"pg.public.{table_name}" in sql_query.lower():
            return full_match
        
        return f"{keyword} pg.public.{table_name}"

    from_join_pattern = re.compile(r'\b(from|join)\s+([a-zA-Z0-9_]+)', re.IGNORECASE)
    prefixed_query = from_join_pattern.sub(add_prefix_if_needed, final_query)

    applied_limit = min(limit, REMOTE_PREVIEW_HARD_LIMIT)
    if limit > REMOTE_PREVIEW_HARD_LIMIT:
        db._log(f"⚠️  Warning: Requested limit of {limit} exceeds the hard limit. Capping at {REMOTE_PREVIEW_HARD_LIMIT} rows.", level="info")
    
    final_query_with_limit = f"{prefixed_query} LIMIT {applied_limit}"

    db._log(f"🛰️  Running remote preview query: {final_query_with_limit}...")
    # We can use the main query function now, which simplifies logic
    return query(db, final_query_with_limit, limit=applied_limit)


def _format_duration(start_time: float) -> str:
    """Formats a duration in a human-readable string."""
    elapsed_s = time.time() - start_time
    if elapsed_s >= 60:
        minutes = int(elapsed_s // 60)
        seconds = elapsed_s % 60
        return f"{minutes}m {seconds:.2f}s"
    elif elapsed_s >= 1:
        return f"{elapsed_s:.2f}s"
    else:
        return f"{elapsed_s * 1000:.2f}ms"


def load_table(
    db: SyntactiqDB,
    source_table_name: str,
    dest_table_name: Optional[str] = None,
    columns: str = "*",
    where_clause: Optional[str] = None,
    limit: Optional[int] = None,
):
    """
    Loads data from a remote PostgreSQL table into a local DuckDB table using
    a highly efficient direct transfer.

    Args:
        db: The SyntactiqDB connection object.
        source_table_name: The name of the PostgreSQL table to load from.
        dest_table_name: Optional name for the new table in DuckDB. If None,
                         defaults to `source_table_name`.
        columns: A string of comma-separated column names to load. Defaults to "*" (all columns).
        where_clause: An optional SQL WHERE clause to filter data.
        limit: An optional limit on the number of rows to load.
    """
    if dest_table_name is None:
        dest_table_name = source_table_name

    remote_table_ref = f"pg.public.{source_table_name}"
    
    query_parts = [f"SELECT {columns} FROM {remote_table_ref}"]
    if where_clause:
        query_parts.append(f"WHERE {where_clause}")
    if limit is not None:
        query_parts.append(f"LIMIT {limit}")
    
    full_query = " ".join(query_parts)

    try:
        db._log("🚀 Transferring data from PostgreSQL to DuckDB...")
        db._log(f"   Executing: CREATE OR REPLACE TABLE {dest_table_name} AS {full_query}")
        start_time = time.time()
        
        if db.conn:
            db.conn.execute(f"CREATE OR REPLACE TABLE {dest_table_name} AS {full_query}")
        
        row_count_df = query(db, f"SELECT COUNT(*) FROM {dest_table_name}", limit=None)
        row_count = row_count_df.iloc[0,0] if not row_count_df.empty else 0
        duration_str = _format_duration(start_time)
        
        db._log(f"✅ Successfully created local table '{dest_table_name}' with {row_count} rows in {duration_str}.", level="info")
    except Exception as e:
        raise QueryError(f"Failed to load table '{source_table_name}'. Hint: load_table runs on DuckDB against the attached Postgres DB. Error: {e}") from e


def create_table_from_query(db: SyntactiqDB, new_table_name: str, sql_query: str):
    """
    Creates a new local DuckDB table from the result of a SQL query.
    """
    if not db.conn:
        raise ConnectionError("DuckDB connection is not available.")
    
    query_sql = f"CREATE OR REPLACE TABLE {new_table_name} AS {sql_query};"
    try:
        db._log(f"📝 Creating table '{new_table_name}' from query...")
        start_time = time.time()
        db.conn.execute(query_sql)
        duration_str = _format_duration(start_time)
        row_count_df = query(db, f"SELECT COUNT(*) FROM {new_table_name}", limit=None)
        row_count = row_count_df.iloc[0,0] if not row_count_df.empty else 0
        if row_count == 0:
            db._log(f"⚠️ Warning: Query produced no results. Table '{new_table_name}' is empty. ({duration_str})", level="info")
        else:
            db._log(f"✅ Successfully created table '{new_table_name}' with {row_count} rows in {duration_str}.", level="info")
    except Exception as e:
        raise QueryError(
            f"Failed to create table '{new_table_name}' from query. "
            f"Hint: This query runs on DuckDB. Error: {e}"
        ) from e


def query(db: SyntactiqDB, sql_query: str, limit: Optional[int] = 500_000) -> pd.DataFrame:
    """
    Executes a SQL query against the DuckDB database and returns the result.
    The query can span across both local tables and remote PostgreSQL tables.
    """
    if not db.conn:
        raise ConnectionError("DuckDB connection is not available.")
    
    HARD_LIMIT = 500_000
    final_query = sql_query.strip().rstrip(';')
    limit_pattern = re.compile(r'limit\s+(\d+)\s*$', re.IGNORECASE)
    
    match = limit_pattern.search(final_query)
    applied_limit = limit

    if match:
        existing_limit = int(match.group(1))
        if existing_limit > HARD_LIMIT:
            raise QueryError(f"Query rejected. The provided limit ({existing_limit}) exceeds the hard limit of {HARD_LIMIT} rows.")
        applied_limit = existing_limit
    
    if applied_limit is None or applied_limit > HARD_LIMIT:
        applied_limit = HARD_LIMIT
    
    if not match and not final_query.strip().lower().startswith(('pragma', 'describe')):
        final_query = f"{final_query} LIMIT {applied_limit}"
    
    try:
        db._log(f"🏃 Running query: {final_query[:200]}...")
        start_time = time.time()
        cursor = db.conn.execute(final_query)
        data = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        result_df = pd.DataFrame(data, columns=columns)
        duration_str = _format_duration(start_time)
        
        if len(result_df) == applied_limit:
            db._log(f"⚠️  Warning: Query result may have been capped at {applied_limit} rows.", level="info")

        db._log(f"✅ Query returned {len(result_df)} rows in {duration_str}.", level="info")
        return result_df
    except Exception as e:
        hint = "DuckDB"
        if "pg.public" in final_query:
            hint = "DuckDB against the attached PostgreSQL database"
        raise QueryError(f"Query failed. Hint: This query runs on {hint}. Error: {e}") from e


def health_check() -> dict:
    """
    Performs a health check by attempting to connect to the databases.
    """
    try:
        with connect():
            pass
        return { "status": "ok", "message": "Connection successful." }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def explore_local_tables(db: SyntactiqDB) -> pd.DataFrame:
    """
    Lists all user-created tables in the **local DuckDB instance**.
    This excludes DuckDB's internal and system tables.
    """
    if not db.conn:
        raise ConnectionError("DuckDB connection is not available.")
    
    # The duckdb_tables() function provides a 'schema_name' column.
    sql = """
        SELECT table_name, schema_name AS table_schema
        FROM duckdb_tables() 
        WHERE schema_name = 'main' 
        AND internal = false
        ORDER BY table_name;
    """
    try:
        db._log(f"🔎 Exploring user-created local tables...")
        return query(db, sql, limit=None)
    except Exception as e:
        raise QueryError(f"Failed to explore local tables: {e}") from e


def get_local_table_schema(db: SyntactiqDB, table_name: str, display_rows: int = 100) -> str:
    """
    Returns a description of a table from the **local DuckDB instance**.
    """
    if not db.conn:
        raise ConnectionError("DuckDB connection is not available.")

    try:
        # Verify table exists
        tables_df = explore_local_tables(db)
        if table_name not in tables_df["table_name"].values:
            raise TableNotFound(f"Table '{table_name}' not found in the local DuckDB instance.")

        db._log(f"📄 Describing schema for local table '{table_name}'...")
        columns_df = query(db, f"DESCRIBE {table_name};", limit=None)

        db._log(f" échantillon... (Fetching {display_rows} sample rows from local table)...")
        sample_rows_df = query(db, f"SELECT * FROM {table_name} LIMIT {display_rows}")

        description = f"Local Table: {table_name}\\n\\n"
        description += "Columns:\\n"
        description += columns_df[["column_name", "column_type"]].to_string(index=False)
        description += f"\\n\\nSample Rows ({display_rows} rows):\\n"
        description += sample_rows_df.to_string(index=False)
        
        db._log("✅ Successfully generated local table description.", level="info")
        return description
    except Exception as e:
        raise QueryError(f"Failed to get local schema for table '{table_name}': {e}") from e


def preview_local_data(db: SyntactiqDB, sql_query: str, limit: int = 100) -> pd.DataFrame:
    """
    Executes a query against the local DuckDB database for a quick preview of the data.

    This function is a safe wrapper and has a non-overridable hard limit of 100 rows.
    """
    limit_pattern = re.compile(r'limit\s+\d+\s*$', re.IGNORECASE)
    if limit_pattern.search(sql_query.strip().rstrip(';')):
        raise QueryError(
            "Query rejected. Do not include a 'LIMIT' clause in `preview_local_data`. "
            "Use the 'limit' parameter instead."
        )

    LOCAL_PREVIEW_HARD_LIMIT = 100
    applied_limit = min(limit, LOCAL_PREVIEW_HARD_LIMIT)
    if limit > LOCAL_PREVIEW_HARD_LIMIT:
        db._log(
            f"⚠️  Warning: Requested limit of {limit} exceeds the hard limit. "
            f"Capping at {LOCAL_PREVIEW_HARD_LIMIT} rows."
        )
    return query(db, sql_query, limit=applied_limit)


def show_table(db: SyntactiqDB, table_name: str, n: int = 500_000) -> pd.DataFrame:
    """
    Displays the first n rows of a table in DuckDB.
    """
    return query(db, f"SELECT * FROM {table_name}", limit=n)


def table_to_df(db: SyntactiqDB, table_name: str, limit: int = 500_000) -> pd.DataFrame:
    """
    Converts a DuckDB table to a pandas DataFrame with a row limit.
    """
    return query(db, f"SELECT * FROM {table_name}", limit=limit)


def close(db: SyntactiqDB):
    """
    Closes the database connection and releases resources.
    It's best practice to call this when you are finished with your analysis.

    Args:
        db: The SyntactiqDB connection object to close.
    """
    if db:
        db.close() 