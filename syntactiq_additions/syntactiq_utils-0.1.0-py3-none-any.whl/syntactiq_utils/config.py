"""Configuration management for database connections."""

import os
from typing import Dict

from .exceptions import ConnectionError
from .fonts import get_default_font_path


def get_postgres_credentials() -> Dict[str, str]:
    """
    Retrieves PostgreSQL connection details from environment variables.

    Returns:
        A dictionary with PostgreSQL connection parameters.

    Raises:
        ConnectionError: If any of the required environment variables
                         (PG_USER, PG_PASSWORD, PG_HOST, PG_PORT, PG_DATABASE)
                         are not set.
    """
    required_vars = [
        "PG_USER",
        "PG_PASSWORD",
        "PG_HOST",
        "PG_PORT",
        "PG_DATABASE",
    ]
    creds = {}
    missing_vars = []

    for var in required_vars:
        value = os.environ.get(var)
        if value is None:
            missing_vars.append(var)
        else:
            creds[var.lower()] = value

    if missing_vars:
        raise ConnectionError(
            f"Missing required environment variables for PostgreSQL connection: "
            f"{', '.join(missing_vars)}. Please set them before connecting."
        )

    return creds


def get_postgres_connection_string() -> str:
    """
    Constructs a PostgreSQL connection string from environment variables.

    Returns:
        A PostgreSQL connection string.
    """
    creds = get_postgres_credentials()
    return (
        f"postgresql://{creds['pg_user']}:{creds['pg_password']}@"
        f"{creds['pg_host']}:{creds['pg_port']}/{creds['pg_database']}"
    )


def get_report_config() -> Dict:
    """
    Provides a standardized configuration for PDF report styling.
    Following scientific publication best practices for typography and layout.

    Returns:
        A dictionary containing styling parameters for fonts, colors,
        margins, and spacing optimized for academic/scientific documents.
    """
    return {
        # Font paths - using embedded DIN Next fonts
        "font_family": get_default_font_path("body") or "Helvetica",
        "font_family_bold": get_default_font_path("body_bold") or "Helvetica-Bold",
        "font_family_heading": get_default_font_path("heading") or "Helvetica-Bold",
        "font_family_title": get_default_font_path("title") or "Helvetica-Bold",
        "font_family_caption": get_default_font_path("caption") or "Helvetica",
        
        # Font sizes - organized in nested dictionary
        "font_sizes": {
            "title": 16,    # More conservative for scientific papers
            "heading": 14,  # Section headings
            "body": 11,     # Standard academic body text
            "table": 9,     # Smaller for data tables
            "caption": 9,   # Figure/table captions
        },
        
        # Colors - organized in nested dictionary
        "colors": {
            "text": "#2d3748",           # Main text color (dark grey)
            "primary": "#2d3748",        # Dark grey for headings (not pure black)
            "secondary": "#4a5568",      # Medium grey for body text
            "accent": "#f7fafc",         # Very light grey for backgrounds
            "highlight": "#F5AF00",      # Corporate color for highlight boxes
            "table_header": "#2d3748",   # Dark grey header
            "table_header_text": "#ffffff", # White text on dark header
            "table_border": "#cbd5e0",   # Light grey borders
            "table_alt_row": "#f7fafc",  # Very subtle alternating rows
        },
        
        # Layout - 1 inch margins (72pt = 1 inch) for academic standards
        "page_margin_top": 72,     # 1 inch margins (72pt = 1 inch)
        "page_margin_right": 72,   # Standard academic margins
        "page_margin_bottom": 72,  # Consistent all around
        "page_margin_left": 72,    # Professional appearance
        
        # Spacing - extremely tight for academic look
        "vertical_spacing": 1,     # Minimal spacing between elements
        "section_spacing": 3,      # Very minimal section breaks
        "title_spacing": 4,        # Very minimal space after main title
        "table_padding": 4,        # Compact table padding
        "border_width": 0.5,       # Subtle borders
        "hint_box_padding": 10,    # Compact callout boxes
        "line_height_multiplier": 1.2,  # Academic line spacing (not double)
        
        # Debug settings
        "debug_mode": False,       # Show borders around elements for debugging
    } 